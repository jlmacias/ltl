package prospec.model.pattern;
import prospec.model.proposition.Proposition;



public class Universality extends Pattern 
{
	public Universality(Proposition P) 
	{
		this.P = P;
	}

}