package prospec.model.pattern;
import prospec.model.proposition.Proposition;


public class Absence extends Pattern
{

		public Absence(Proposition P) 
		{
			this.P = P;
		}
		
}
