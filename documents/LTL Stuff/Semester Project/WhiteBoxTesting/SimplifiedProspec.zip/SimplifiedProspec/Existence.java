package prospec.model.pattern;
import prospec.model.proposition.Proposition;


public class Existence extends Pattern 
{

		public Existence(Proposition P) 
		{
			this.P = P;
		}
}
