package prospec.model.scope;


public class Global extends Scope {

}
