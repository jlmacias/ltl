To run in a command line:
java -jar LTLGen.jar

Requires input.txt for input, formulas will be written to output.txt.

Input file is not very robust so follow pattern.
Scopes:
Global
AfterL
BeforeR
AfterLuntilR
BetweenLandR


Patterns:
Absence
Existence
Universality
Precedence
Response
StrictPrecedence

CPs
AtLeastOneC
AtLeastOneE
ParallelC
ParallelE
ConsecutiveC
ConsecutiveE
EventualC
EventualE